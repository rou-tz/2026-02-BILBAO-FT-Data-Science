
# WattUp — App móvil de ahorro eléctrico gamificada

App mobile-first (contenedor centrado tipo móvil en desktop) con la mascota **Watt** como hilo conductor. Demo local: todo se guarda en el navegador (localStorage), sin backend. Contraseñas hasheadas con **SHA-512 + salt** antes de guardarse.

## Arquitectura de rutas (TanStack Router)

- `/` → Bienvenida + Login/Registro (Watt saludando)
- `/dashboard` → Inicio con Watt y resumen del día
- `/registrar` → Registro de actividad de electrodomésticos
- `/perfil` → Estadísticas, nivel, insignias, gráfico semanal
- `/amigos` → Buscador, lista de amigos y ranking semanal
- Layout protegido `_app` con barra de navegación inferior fija (Inicio · Registrar · Perfil · Amigos) — solo accesible tras login, redirige a `/` si no hay sesión.

## Pantallas en detalle

### 1. Bienvenida / Login / Registro
- Logo WattUp + ilustración de Watt (pila redondeada con ojos) saludando con la mano.
- Tabs **Iniciar sesión / Crear cuenta**.
- Registro: nombre, email, contraseña + confirmar.
- **Reglas de contraseña segura**: mínimo 8 caracteres, 1 mayúscula, 1 minúscula, 1 número, 1 símbolo. Indicador visual de fortaleza en vivo.
- **Hash SHA-512 + salt aleatorio** por usuario (Web Crypto API), guardado en localStorage.
- **Máximo de intentos de login**: 5 fallos → bloqueo de 15 minutos con cuenta atrás visible. Contador persistido.
- Botón principal verde eléctrico (#4CAF50), bordes redondeados.

### 2. Dashboard
- Watt grande centrado con **3 estados visuales** (feliz saltando / neutro / triste caído) según % de objetivo del día.
- Barra de progreso circular alrededor de Watt con % de objetivo cumplido.
- Tarjeta "Hoy has gastado **X €** · Objetivo **Y €**" (rojo suave si supera objetivo, verde si está por debajo).
- Lista de **top 3 electrodomésticos** del día con icono, kWh y €.
- Botón CTA grande amarillo energía (#FFD600): **"Registrar mi día"** → `/registrar`.
- Microanimación: Watt parpadea y respira; salta al cargar si hay ahorro.

### 3. Registrar actividad
- Grid visual de electrodomésticos con icono e ilustración flat: lavadora, televisor, router, calefacción, ducha eléctrica, horno, luces.
- Cada uno: toggle de uso + selector de tiempo (horas/minutos con stepper redondeado).
- Cálculo en vivo:
  - Consumo real = Σ(potencia × horas) × 0,18 €/kWh
  - Consumo responsable = mismos aparatos en horario valle / temperatura óptima / sin standby
  - **CO₂ evitado** = kWh ahorrados × 0,19 kg/kWh (factor medio España)
- Dos tarjetas lado a lado, grandes: **"Lo que has gastado: X €"** (rojo suave) vs **"Uso responsable: Y €"** (verde). Ahorro potencial destacado abajo en verde grande.
- Al guardar: Watt salta/se entristece según resultado, toast con confirmación, redirige al dashboard.
- Tabla interna de consumos estándar y responsables por electrodoméstico (kWh/h).

### 4. Perfil
- Avatar circular + nombre + **nivel** según racha de días con ahorro:
  - 0–6 días: 🌱 Principiante
  - 7–20 días: ⚡ Ahorrador
  - 21+ días: 🏆 Eco-experto
- Tres tarjetas KPI del mes: **kWh ahorrados**, **€ ahorrados**, **kg CO₂ evitados**.
- **Gráfico de barras semanal** (lun–dom) de consumo diario en kWh, con línea de objetivo.
- Cuadrícula de **insignias** desbloqueables: Primer día, Racha 7 días, Sin standby, Maestro de la lavadora, Eco-experto, etc. (bloqueadas en gris, desbloqueadas a color).
- Botón cerrar sesión.

### 5. Amigos y ranking
- Buscador por nombre de usuario (busca entre demo + usuarios locales).
- **Mis amigos**: lista con avatar, nombre, % batería de Watt y posición.
- **Ranking semanal Top 10**: posición, avatar, nombre, kWh ahorrados, mini-Watt con su estado. El usuario actual resaltado.
- Datos demo precargados: 8–10 amigos ficticios con historial semanal realista para que el ranking esté vivo desde el primer login.

## Sistema de cálculo (módulo `lib/energy.ts`)

- Constante `PRICE_KWH = 0.18`, `CO2_PER_KWH = 0.19`.
- Catálogo de electrodomésticos con `{ id, nombre, icono, kWhPorHora, kWhResponsablePorHora }`.
- Funciones: `calcularConsumo(actividades)`, `calcularAhorro()`, `estadoWatt(porcentajeObjetivo)`, `nivelUsuario(racha)`.

## Seguridad (demo local)

- SHA-512 + salt único por usuario vía `crypto.subtle.digest`.
- Validación de contraseña con regex y feedback en tiempo real.
- Rate limiting de login: 5 intentos → 15 min de bloqueo persistido.
- Sesión en localStorage con expiración (24h).
- Aviso visible: "Demo local — datos guardados en este dispositivo".

## Diseño

- **Paleta**: fondo #FAFAF7 casi blanco, acento verde #4CAF50, amarillo #FFD600, rojo suave #FF8A80, texto gris oscuro.
- **Tipografía**: Nunito (Google Fonts) — redondeada, amigable, familiar.
- **Bordes**: radius generoso (16–24px) en todo. Cero aristas.
- **Watt**: SVG inline reutilizable con props para 3 estados (feliz/neutro/triste) + animaciones CSS (salto, parpadeo, caída).
- **Microanimaciones** estilo Duolingo: bounce al pulsar botones, pulse en CTAs, slide-in de tarjetas, confeti suave al desbloquear insignia.
- Contenedor móvil centrado (max 430px) con sombra suave en desktop, fullscreen en móvil.
- Barra de navegación inferior fija con 4 iconos + etiqueta, ítem activo en verde.

## Datos demo precargados

- 9 amigos ficticios con nombres, avatares (iniciales coloreadas), kWh ahorrados y % batería de Watt.
- Historial de los últimos 7 días para el usuario nuevo (valores realistas).
- 3 insignias ya desbloqueadas de bienvenida.
