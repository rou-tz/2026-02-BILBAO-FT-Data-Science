/**
 * WattUp — auth local (demo).
 * Hash SHA-512 + salt aleatorio por usuario.
 * Rate limiting: 5 intentos → 15 min de bloqueo.
 * Sesión 24h en localStorage.
 */

const USERS_KEY = "wattup:users";
const SESSION_KEY = "wattup:session";
const ATTEMPTS_KEY = "wattup:loginAttempts";

const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000;
const SESSION_MS = 24 * 60 * 60 * 1000;

export interface StoredUser {
  id: string;
  nombre: string;
  email: string;
  saltHex: string;
  hashHex: string;
  createdAt: number;
}

export interface Session {
  userId: string;
  email: string;
  nombre: string;
  expiresAt: number;
}

function isBrowser() {
  return typeof window !== "undefined";
}

function readJSON<T>(key: string, fallback: T): T {
  if (!isBrowser()) return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeJSON(key: string, value: unknown) {
  if (!isBrowser()) return;
  localStorage.setItem(key, JSON.stringify(value));
}

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export function generateSaltHex(byteLen = 16): string {
  const arr = new Uint8Array(byteLen);
  crypto.getRandomValues(arr);
  return bytesToHex(arr);
}

export async function hashPasswordSHA512(password: string, saltHex: string): Promise<string> {
  const enc = new TextEncoder();
  const data = enc.encode(saltHex + ":" + password);
  const digest = await crypto.subtle.digest("SHA-512", data);
  return bytesToHex(new Uint8Array(digest));
}

export interface PasswordCheck {
  ok: boolean;
  score: 0 | 1 | 2 | 3 | 4;
  rules: { label: string; ok: boolean }[];
}

export function checkPassword(pw: string): PasswordCheck {
  const rules = [
    { label: "Al menos 8 caracteres", ok: pw.length >= 8 },
    { label: "Una mayúscula", ok: /[A-Z]/.test(pw) },
    { label: "Una minúscula", ok: /[a-z]/.test(pw) },
    { label: "Un número", ok: /\d/.test(pw) },
    { label: "Un símbolo", ok: /[^A-Za-z0-9]/.test(pw) },
  ];
  const passed = rules.filter((r) => r.ok).length;
  const score = (passed >= 5 ? 4 : passed >= 4 ? 3 : passed >= 3 ? 2 : passed >= 2 ? 1 : 0) as
    | 0
    | 1
    | 2
    | 3
    | 4;
  return { ok: rules.every((r) => r.ok), score, rules };
}

function getUsers(): StoredUser[] {
  return readJSON<StoredUser[]>(USERS_KEY, []);
}

function setUsers(users: StoredUser[]) {
  writeJSON(USERS_KEY, users);
}

export async function registerUser(input: {
  nombre: string;
  email: string;
  password: string;
}): Promise<{ ok: true; user: StoredUser } | { ok: false; error: string }> {
  const email = input.email.trim().toLowerCase();
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { ok: false, error: "Email no válido" };
  }
  if (!input.nombre.trim()) return { ok: false, error: "El nombre es obligatorio" };
  if (!checkPassword(input.password).ok) {
    return { ok: false, error: "La contraseña no cumple los requisitos" };
  }
  const users = getUsers();
  if (users.some((u) => u.email === email)) {
    return { ok: false, error: "Ya existe una cuenta con ese email" };
  }
  const saltHex = generateSaltHex();
  const hashHex = await hashPasswordSHA512(input.password, saltHex);
  const user: StoredUser = {
    id: crypto.randomUUID(),
    nombre: input.nombre.trim().slice(0, 60),
    email,
    saltHex,
    hashHex,
    createdAt: Date.now(),
  };
  users.push(user);
  setUsers(users);
  return { ok: true, user };
}

interface AttemptsRecord {
  count: number;
  lockedUntil: number;
}

function getAttempts(email: string): AttemptsRecord {
  const all = readJSON<Record<string, AttemptsRecord>>(ATTEMPTS_KEY, {});
  return all[email] ?? { count: 0, lockedUntil: 0 };
}

function setAttempts(email: string, rec: AttemptsRecord) {
  const all = readJSON<Record<string, AttemptsRecord>>(ATTEMPTS_KEY, {});
  all[email] = rec;
  writeJSON(ATTEMPTS_KEY, all);
}

export function getLockoutRemaining(email: string): number {
  const rec = getAttempts(email.trim().toLowerCase());
  return Math.max(0, rec.lockedUntil - Date.now());
}

export async function loginUser(input: {
  email: string;
  password: string;
}): Promise<
  | { ok: true; session: Session }
  | { ok: false; error: string; lockedMs?: number; remainingAttempts?: number }
> {
  const email = input.email.trim().toLowerCase();
  const rec = getAttempts(email);
  if (rec.lockedUntil > Date.now()) {
    return {
      ok: false,
      error: "Cuenta bloqueada por demasiados intentos.",
      lockedMs: rec.lockedUntil - Date.now(),
    };
  }
  const user = getUsers().find((u) => u.email === email);
  if (!user) {
    const next = { count: rec.count + 1, lockedUntil: 0 };
    if (next.count >= MAX_ATTEMPTS) next.lockedUntil = Date.now() + LOCKOUT_MS;
    setAttempts(email, next);
    return {
      ok: false,
      error: "Email o contraseña incorrectos",
      remainingAttempts: Math.max(0, MAX_ATTEMPTS - next.count),
      lockedMs: next.lockedUntil > 0 ? LOCKOUT_MS : undefined,
    };
  }
  const hash = await hashPasswordSHA512(input.password, user.saltHex);
  if (hash !== user.hashHex) {
    const next = { count: rec.count + 1, lockedUntil: 0 };
    if (next.count >= MAX_ATTEMPTS) next.lockedUntil = Date.now() + LOCKOUT_MS;
    setAttempts(email, next);
    return {
      ok: false,
      error: "Email o contraseña incorrectos",
      remainingAttempts: Math.max(0, MAX_ATTEMPTS - next.count),
      lockedMs: next.lockedUntil > 0 ? LOCKOUT_MS : undefined,
    };
  }
  // Éxito → reset contador
  setAttempts(email, { count: 0, lockedUntil: 0 });
  const session: Session = {
    userId: user.id,
    email: user.email,
    nombre: user.nombre,
    expiresAt: Date.now() + SESSION_MS,
  };
  writeJSON(SESSION_KEY, session);
  return { ok: true, session };
}

export function getSession(): Session | null {
  const s = readJSON<Session | null>(SESSION_KEY, null);
  if (!s) return null;
  if (s.expiresAt < Date.now()) {
    if (isBrowser()) localStorage.removeItem(SESSION_KEY);
    return null;
  }
  return s;
}

export function logout() {
  if (isBrowser()) localStorage.removeItem(SESSION_KEY);
}
