/**
 * WattUp — almacén local de datos del usuario:
 * historial de actividades, amigos y ranking demo, insignias.
 */

import { ActivityEntry, calcularConsumo, DAILY_GOAL_EUR } from "./energy";

const ACTIVITIES_KEY = "wattup:activities";
const FRIENDS_KEY = "wattup:friends";
const BADGES_KEY = "wattup:badges";
const SEED_KEY = "wattup:seeded";

export interface DayActivity {
  userId: string;
  date: string; // YYYY-MM-DD
  entries: ActivityEntry[];
  euros: number;
  kWh: number;
  ahorroEuros: number;
  ahorroKWh: number;
  co2EvitadoKg: number;
}

export interface Friend {
  id: string;
  nombre: string;
  username: string;
  color: string; // avatar bg
  semanaKWhAhorrados: number;
  bateriaPct: number;
}

export interface Badge {
  id: string;
  nombre: string;
  emoji: string;
  descripcion: string;
  desbloqueada: boolean;
}

const ALL_BADGES: Badge[] = [
  { id: "first_day", nombre: "Primer día", emoji: "🎉", descripcion: "Registra tu primer día", desbloqueada: false },
  { id: "streak_7", nombre: "Racha de 7", emoji: "🔥", descripcion: "7 días seguidos ahorrando", desbloqueada: false },
  { id: "no_standby", nombre: "Sin standby", emoji: "🔌", descripcion: "Un día sin TV en standby", desbloqueada: false },
  { id: "lavadora", nombre: "Maestro lavadora", emoji: "🧺", descripcion: "5 lavados eco", desbloqueada: false },
  { id: "eco_expert", nombre: "Eco-experto", emoji: "🏆", descripcion: "21 días de racha", desbloqueada: false },
  { id: "saver_5", nombre: "Ahorrador 5€", emoji: "💶", descripcion: "Ahorra 5€ en una semana", desbloqueada: false },
  { id: "co2_killer", nombre: "Anti-CO₂", emoji: "🌍", descripcion: "1 kg CO₂ evitado", desbloqueada: false },
  { id: "night_owl", nombre: "Búho nocturno", emoji: "🌙", descripcion: "Usa horario valle", desbloqueada: false },
];

function readJSON<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeJSON(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  localStorage.setItem(key, JSON.stringify(value));
}

export function todayKey(d = new Date()): string {
  return d.toISOString().slice(0, 10);
}

function daysAgoKey(n: number): string {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return todayKey(d);
}

export function getActivities(userId: string): DayActivity[] {
  return readJSON<DayActivity[]>(ACTIVITIES_KEY, []).filter((a) => a.userId === userId);
}

export function saveActivity(userId: string, entries: ActivityEntry[]): DayActivity {
  const calc = calcularConsumo(entries);
  const day: DayActivity = {
    userId,
    date: todayKey(),
    entries,
    euros: calc.euros,
    kWh: calc.kWh,
    ahorroEuros: calc.ahorroEuros,
    ahorroKWh: calc.ahorroKWh,
    co2EvitadoKg: calc.co2EvitadoKg,
  };
  const all = readJSON<DayActivity[]>(ACTIVITIES_KEY, []).filter(
    (a) => !(a.userId === userId && a.date === day.date),
  );
  all.push(day);
  writeJSON(ACTIVITIES_KEY, all);
  // Auto-unlock first_day badge
  unlockBadge(userId, "first_day");
  if (day.ahorroEuros >= 1) unlockBadge(userId, "no_standby");
  if (day.co2EvitadoKg >= 1) unlockBadge(userId, "co2_killer");
  return day;
}

export function getTodayActivity(userId: string): DayActivity | null {
  const today = todayKey();
  return getActivities(userId).find((a) => a.date === today) ?? null;
}

export function getWeekActivities(userId: string): DayActivity[] {
  const acts = getActivities(userId);
  const days: DayActivity[] = [];
  for (let i = 6; i >= 0; i--) {
    const date = daysAgoKey(i);
    const found = acts.find((a) => a.date === date);
    days.push(
      found ?? {
        userId,
        date,
        entries: [],
        euros: 0,
        kWh: 0,
        ahorroEuros: 0,
        ahorroKWh: 0,
        co2EvitadoKg: 0,
      },
    );
  }
  return days;
}

export function getRacha(userId: string): number {
  // Días consecutivos (incluyendo hoy hacia atrás) con ahorro > 0 OR gasto bajo objetivo
  const acts = getActivities(userId);
  let racha = 0;
  for (let i = 0; i < 60; i++) {
    const k = daysAgoKey(i);
    const a = acts.find((x) => x.date === k);
    if (!a) break;
    if (a.euros <= DAILY_GOAL_EUR) racha++;
    else break;
  }
  return racha;
}

export function getMonthStats(userId: string): {
  kWhAhorrados: number;
  eurosAhorrados: number;
  co2EvitadoKg: number;
} {
  const now = new Date();
  const acts = getActivities(userId).filter((a) => {
    const d = new Date(a.date);
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });
  return {
    kWhAhorrados: acts.reduce((s, a) => s + a.ahorroKWh, 0),
    eurosAhorrados: acts.reduce((s, a) => s + a.ahorroEuros, 0),
    co2EvitadoKg: acts.reduce((s, a) => s + a.co2EvitadoKg, 0),
  };
}

/* ---------- Friends & Ranking ---------- */

const DEMO_FRIENDS: Friend[] = [
  { id: "f1", nombre: "Lucía", username: "lucia_eco", color: "#4CAF50", semanaKWhAhorrados: 14.2, bateriaPct: 92 },
  { id: "f2", nombre: "Mateo", username: "mateowatt", color: "#FFD600", semanaKWhAhorrados: 11.7, bateriaPct: 84 },
  { id: "f3", nombre: "Sofía", username: "sofi_green", color: "#FF8A80", semanaKWhAhorrados: 9.1, bateriaPct: 70 },
  { id: "f4", nombre: "Hugo", username: "hugo_h", color: "#64B5F6", semanaKWhAhorrados: 7.8, bateriaPct: 64 },
  { id: "f5", nombre: "Carla", username: "carlita", color: "#BA68C8", semanaKWhAhorrados: 6.3, bateriaPct: 55 },
  { id: "f6", nombre: "Diego", username: "dieguete", color: "#FF7043", semanaKWhAhorrados: 5.0, bateriaPct: 48 },
  { id: "f7", nombre: "Aitana", username: "ai_tana", color: "#26A69A", semanaKWhAhorrados: 4.1, bateriaPct: 40 },
  { id: "f8", nombre: "Pablo", username: "p4blito", color: "#FFA726", semanaKWhAhorrados: 2.7, bateriaPct: 28 },
  { id: "f9", nombre: "Noa", username: "noa_volt", color: "#9CCC65", semanaKWhAhorrados: 1.4, bateriaPct: 18 },
];

export function getFriends(): Friend[] {
  return readJSON<Friend[]>(FRIENDS_KEY, DEMO_FRIENDS);
}

export function addFriend(username: string): Friend | null {
  const u = username.trim().toLowerCase();
  if (!u) return null;
  const existing = getFriends().find((f) => f.username === u);
  if (existing) return existing;
  const colors = ["#4CAF50", "#FFD600", "#FF8A80", "#64B5F6", "#BA68C8", "#FF7043"];
  const f: Friend = {
    id: crypto.randomUUID(),
    nombre: u.charAt(0).toUpperCase() + u.slice(1),
    username: u,
    color: colors[Math.floor(Math.random() * colors.length)],
    semanaKWhAhorrados: Math.round(Math.random() * 8 * 10) / 10,
    bateriaPct: 30 + Math.floor(Math.random() * 60),
  };
  const all = [...getFriends(), f];
  writeJSON(FRIENDS_KEY, all);
  return f;
}

/* ---------- Badges ---------- */

export function getBadges(userId: string): Badge[] {
  const all = readJSON<Record<string, string[]>>(BADGES_KEY, {});
  const unlocked = new Set(all[userId] ?? []);
  return ALL_BADGES.map((b) => ({ ...b, desbloqueada: unlocked.has(b.id) }));
}

export function unlockBadge(userId: string, id: string) {
  const all = readJSON<Record<string, string[]>>(BADGES_KEY, {});
  const cur = new Set(all[userId] ?? []);
  if (cur.has(id)) return;
  cur.add(id);
  all[userId] = Array.from(cur);
  writeJSON(BADGES_KEY, all);
}

/* ---------- Seed demo ---------- */

export function seedDemoIfNeeded(userId: string) {
  if (typeof window === "undefined") return;
  const seeded = readJSON<Record<string, boolean>>(SEED_KEY, {});
  if (seeded[userId]) return;

  // Sembrar 30 días previos (no hoy) con escenarios variados:
  // días eco, días normales, días de derroche, fin de semana con horno y calefacción, etc.
  const all = readJSON<DayActivity[]>(ACTIVITIES_KEY, []);
  const round = (n: number) => Math.round(n * 100) / 100;

  for (let i = 30; i >= 1; i--) {
    const date = daysAgoKey(i);
    if (all.some((a) => a.userId === userId && a.date === date)) continue;

    const dow = new Date(date).getDay(); // 0=dom, 6=sab
    const isWeekend = dow === 0 || dow === 6;
    // Tipo de día: 0 eco, 1 normal, 2 derroche
    // Patrón ciclico para tener variedad clara
    const cycle = i % 7;
    let tipo: 0 | 1 | 2;
    if (cycle === 0 || cycle === 3) tipo = 0; // eco
    else if (cycle === 5) tipo = 2; // derroche
    else tipo = 1; // normal
    if (isWeekend && tipo !== 2 && i % 4 === 0) tipo = 2;

    const entries: ActivityEntry[] = [];

    // Luces: siempre, varía con el día
    entries.push({
      applianceId: "luces",
      horas: round(tipo === 0 ? 2 + Math.random() * 1 : tipo === 1 ? 4 + Math.random() * 2 : 7 + Math.random() * 2),
    });

    // TV
    entries.push({
      applianceId: "television",
      horas: round(tipo === 0 ? 1 + Math.random() : tipo === 1 ? 2.5 + Math.random() * 1.5 : 5 + Math.random() * 2),
    });

    // Router: casi siempre encendido, eco lo apaga de noche
    entries.push({
      applianceId: "router",
      horas: tipo === 0 ? 14 : tipo === 1 ? 18 : 24,
    });

    // Lavadora: 2-3 veces/semana, en derroche más
    if (i % 3 === 0 || tipo === 2) {
      entries.push({ applianceId: "lavadora", horas: tipo === 2 ? 1.5 : 1 });
    }

    // Ducha eléctrica: corta en eco, larga en derroche
    entries.push({
      applianceId: "ducha",
      horas: round(tipo === 0 ? 0.08 : tipo === 1 ? 0.13 : 0.25),
    });

    // Horno: fines de semana o derroche
    if ((isWeekend && tipo !== 0) || tipo === 2) {
      entries.push({ applianceId: "horno", horas: round(0.5 + Math.random() * 0.8) });
    }

    // Calefacción: solo en algunos días (simula días fríos)
    if (i % 4 === 0 || tipo === 2) {
      entries.push({
        applianceId: "calefaccion",
        horas: round(tipo === 0 ? 2 : tipo === 1 ? 4 : 7),
      });
    }

    const calc = calcularConsumo(entries);
    all.push({
      userId,
      date,
      entries,
      euros: calc.euros,
      kWh: calc.kWh,
      ahorroEuros: calc.ahorroEuros,
      ahorroKWh: calc.ahorroKWh,
      co2EvitadoKg: calc.co2EvitadoKg,
    });
  }
  writeJSON(ACTIVITIES_KEY, all);

  // Insignias de bienvenida
  const badgeMap = readJSON<Record<string, string[]>>(BADGES_KEY, {});
  badgeMap[userId] = ["first_day", "no_standby", "night_owl"];
  writeJSON(BADGES_KEY, badgeMap);

  // Friends por defecto si no hay
  if (!localStorage.getItem(FRIENDS_KEY)) {
    writeJSON(FRIENDS_KEY, DEMO_FRIENDS);
  }

  seeded[userId] = true;
  writeJSON(SEED_KEY, seeded);
}
