/**
 * WattUp — sistema de cálculo energético.
 * Precios y factores medios de España.
 */

export const PRICE_KWH = 0.18;
export const CO2_PER_KWH = 0.19; // kg CO2 por kWh (mix eléctrico España)
export const DAILY_GOAL_EUR = 3.0; // objetivo de gasto diario por defecto

export type ApplianceId =
  | "lavadora"
  | "television"
  | "router"
  | "calefaccion"
  | "ducha"
  | "horno"
  | "luces";

export interface Appliance {
  id: ApplianceId;
  nombre: string;
  emoji: string;
  /** kWh por hora de uso estándar */
  kWhPorHora: number;
  /** kWh por hora con uso responsable */
  kWhResponsablePorHora: number;
  /** Horas recomendadas de uso responsable al día */
  horasRecomendadas: number;
  /** Tip para el usuario */
  tip: string;
}

export const APPLIANCES: Appliance[] = [
  {
    id: "lavadora",
    nombre: "Lavadora",
    emoji: "🧺",
    kWhPorHora: 1.2,
    kWhResponsablePorHora: 0.6,
    horasRecomendadas: 1,
    tip: "Programa Eco a 30 °C en horario valle",
  },
  {
    id: "television",
    nombre: "Televisor",
    emoji: "📺",
    kWhPorHora: 0.15,
    kWhResponsablePorHora: 0.08,
    horasRecomendadas: 2,
    tip: "Apaga sin standby al terminar",
  },
  {
    id: "router",
    nombre: "Router WiFi",
    emoji: "📶",
    kWhPorHora: 0.012,
    kWhResponsablePorHora: 0.008,
    horasRecomendadas: 16,
    tip: "Apágalo por la noche",
  },
  {
    id: "calefaccion",
    nombre: "Calefacción",
    emoji: "🔥",
    kWhPorHora: 2.0,
    kWhResponsablePorHora: 1.1,
    horasRecomendadas: 4,
    tip: "Mantén entre 19–21 °C",
  },
  {
    id: "ducha",
    nombre: "Ducha eléctrica",
    emoji: "🚿",
    kWhPorHora: 8.0,
    kWhResponsablePorHora: 4.0,
    horasRecomendadas: 0.1,
    tip: "Duchas de menos de 5 minutos",
  },
  {
    id: "horno",
    nombre: "Horno",
    emoji: "🍞",
    kWhPorHora: 2.3,
    kWhResponsablePorHora: 1.4,
    horasRecomendadas: 0.5,
    tip: "Aprovecha el calor residual",
  },
  {
    id: "luces",
    nombre: "Luces",
    emoji: "💡",
    kWhPorHora: 0.2,
    kWhResponsablePorHora: 0.08,
    horasRecomendadas: 5,
    tip: "Cambia a LED y apaga al salir",
  },
];

export const APPLIANCE_MAP: Record<ApplianceId, Appliance> = APPLIANCES.reduce(
  (acc, a) => ({ ...acc, [a.id]: a }),
  {} as Record<ApplianceId, Appliance>,
);

export interface ActivityEntry {
  applianceId: ApplianceId;
  /** Horas de uso (decimal) */
  horas: number;
}

export interface ConsumoCalculado {
  kWh: number;
  euros: number;
  kWhResponsable: number;
  eurosResponsable: number;
  ahorroKWh: number;
  ahorroEuros: number;
  co2EvitadoKg: number;
  porApliacacion: Array<{
    appliance: Appliance;
    kWh: number;
    euros: number;
  }>;
}

export function calcularConsumo(actividades: ActivityEntry[]): ConsumoCalculado {
  let kWh = 0;
  let kWhResp = 0;
  const porApliacacion: ConsumoCalculado["porApliacacion"] = [];

  for (const act of actividades) {
    const ap = APPLIANCE_MAP[act.applianceId];
    if (!ap || act.horas <= 0) continue;
    const k = ap.kWhPorHora * act.horas;
    const kr = ap.kWhResponsablePorHora * act.horas;
    kWh += k;
    kWhResp += kr;
    porApliacacion.push({ appliance: ap, kWh: k, euros: k * PRICE_KWH });
  }

  const ahorroKWh = Math.max(0, kWh - kWhResp);
  return {
    kWh,
    euros: kWh * PRICE_KWH,
    kWhResponsable: kWhResp,
    eurosResponsable: kWhResp * PRICE_KWH,
    ahorroKWh,
    ahorroEuros: ahorroKWh * PRICE_KWH,
    co2EvitadoKg: ahorroKWh * CO2_PER_KWH,
    porApliacacion: porApliacacion.sort((a, b) => b.kWh - a.kWh),
  };
}

export function estadoWatt(eurosGastados: number, objetivo = DAILY_GOAL_EUR): {
  mood: "happy" | "neutral" | "sad";
  porcentaje: number;
} {
  // porcentaje del objetivo cumplido (menos consumo = mejor)
  const ratio = eurosGastados / objetivo;
  const porcentaje = Math.max(0, Math.min(100, Math.round((1 - ratio) * 100 + 50)));
  if (ratio <= 0.7) return { mood: "happy", porcentaje: Math.min(100, porcentaje) };
  if (ratio <= 1.0) return { mood: "neutral", porcentaje };
  return { mood: "sad", porcentaje: Math.max(0, porcentaje) };
}

export function nivelUsuario(rachaDias: number): {
  nombre: string;
  emoji: string;
  siguiente: number | null;
} {
  if (rachaDias >= 21) return { nombre: "Eco-experto", emoji: "🏆", siguiente: null };
  if (rachaDias >= 7) return { nombre: "Ahorrador", emoji: "⚡", siguiente: 21 };
  return { nombre: "Principiante", emoji: "🌱", siguiente: 7 };
}

export function fmtEuro(v: number): string {
  return v.toLocaleString("es-ES", { style: "currency", currency: "EUR", maximumFractionDigits: 2 });
}

export function fmtKWh(v: number): string {
  return `${v.toLocaleString("es-ES", { maximumFractionDigits: 2 })} kWh`;
}
