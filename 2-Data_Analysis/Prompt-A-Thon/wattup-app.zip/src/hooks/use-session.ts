import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { getSession, type Session } from "@/lib/auth";
import { seedDemoIfNeeded } from "@/lib/store";

export function useRequireSession(): Session | null {
  const [session, setSession] = useState<Session | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const s = getSession();
    if (!s) {
      navigate({ to: "/" });
      return;
    }
    seedDemoIfNeeded(s.userId);
    setSession(s);
  }, [navigate]);

  return session;
}
