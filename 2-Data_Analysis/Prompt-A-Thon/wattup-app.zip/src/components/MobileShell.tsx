import { ReactNode } from "react";
import { cn } from "@/lib/utils";

/**
 * Contenedor mobile-first centrado (max 430px) con sombra en desktop.
 */
export function MobileShell({
  children,
  className,
  withNav = false,
}: {
  children: ReactNode;
  className?: string;
  withNav?: boolean;
}) {
  return (
    <div className="min-h-screen w-full bg-muted/40 flex justify-center">
      <div
        className={cn(
          "relative w-full max-w-[430px] min-h-screen bg-background sm:shadow-2xl sm:my-0",
          withNav && "pb-24",
          className,
        )}
      >
        {children}
      </div>
    </div>
  );
}
