import { Link, useLocation } from "@tanstack/react-router";
import { Home, PlusCircle, User, Users } from "lucide-react";
import { cn } from "@/lib/utils";

const items = [
  { to: "/dashboard", label: "Inicio", icon: Home },
  { to: "/registrar", label: "Registrar", icon: PlusCircle },
  { to: "/perfil", label: "Perfil", icon: User },
  { to: "/amigos", label: "Amigos", icon: Users },
] as const;

export function BottomNav() {
  const loc = useLocation();
  return (
    <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] bg-card border-t border-border z-50">
      <ul className="grid grid-cols-4">
        {items.map(({ to, label, icon: Icon }) => {
          const active = loc.pathname === to;
          return (
            <li key={to}>
              <Link
                to={to}
                className={cn(
                  "flex flex-col items-center justify-center gap-1 py-3 transition-colors",
                  active ? "text-primary" : "text-muted-foreground hover:text-foreground",
                )}
              >
                <Icon
                  className={cn("h-6 w-6 transition-transform", active && "scale-110")}
                  strokeWidth={active ? 2.5 : 2}
                />
                <span className={cn("text-xs", active && "font-bold")}>{label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
