import { cn } from "@/lib/utils";

export type WattMood = "happy" | "neutral" | "sad";

interface WattProps {
  mood?: WattMood;
  size?: number;
  battery?: number; // 0-100
  className?: string;
  waving?: boolean;
}

/**
 * Watt — la mascota pila de WattUp.
 * Estilo flat, redondeada, con ojos expresivos.
 */
export function Watt({
  mood = "happy",
  size = 180,
  battery,
  className,
  waving = false,
}: WattProps) {
  const fillPct = battery ?? (mood === "happy" ? 90 : mood === "neutral" ? 55 : 20);
  const fillColor =
    mood === "happy"
      ? "var(--primary)"
      : mood === "sad"
        ? "var(--danger-soft)"
        : "var(--energy)";

  const animClass =
    mood === "happy"
      ? "animate-watt-bounce"
      : mood === "sad"
        ? "animate-watt-sad"
        : "animate-watt-breathe";

  // Body inner area: y from 50 to 200 (height 150). Fill grows from bottom.
  const innerTop = 50;
  const innerHeight = 150;
  const fillHeight = (fillPct / 100) * innerHeight;
  const fillY = innerTop + (innerHeight - fillHeight);

  return (
    <div
      className={cn("inline-block", animClass, className)}
      style={{ width: size, height: size }}
    >
      <svg viewBox="0 0 200 240" width={size} height={size} aria-label="Watt mascot">
        {/* Top cap */}
        <rect x="75" y="10" width="50" height="22" rx="8" fill="var(--watt-body)" />
        <rect x="85" y="2" width="30" height="14" rx="5" fill="var(--watt-body)" />

        {/* Body outline */}
        <rect
          x="30"
          y="32"
          width="140"
          height="180"
          rx="32"
          fill="white"
          stroke="var(--foreground)"
          strokeWidth="6"
        />

        {/* Battery fill */}
        <clipPath id="bodyClip">
          <rect x="36" y="38" width="128" height="168" rx="26" />
        </clipPath>
        <g clipPath="url(#bodyClip)">
          <rect
            x="36"
            y={fillY}
            width="128"
            height={fillHeight + 4}
            fill={fillColor}
            style={{ transition: "all 0.6s ease" }}
          />
          {/* Bubbles */}
          <circle cx="60" cy={fillY + 20} r="4" fill="white" opacity="0.5" />
          <circle cx="140" cy={fillY + 35} r="3" fill="white" opacity="0.5" />
        </g>

        {/* Eyes */}
        {mood === "sad" ? (
          <>
            <path
              d="M 70 110 Q 80 120 90 110"
              stroke="var(--foreground)"
              strokeWidth="5"
              fill="none"
              strokeLinecap="round"
            />
            <path
              d="M 110 110 Q 120 120 130 110"
              stroke="var(--foreground)"
              strokeWidth="5"
              fill="none"
              strokeLinecap="round"
            />
          </>
        ) : (
          <>
            <ellipse
              cx="80"
              cy="115"
              rx="7"
              ry="9"
              fill="var(--foreground)"
              className="animate-blink"
              style={{ transformOrigin: "80px 115px" }}
            />
            <ellipse
              cx="120"
              cy="115"
              rx="7"
              ry="9"
              fill="var(--foreground)"
              className="animate-blink"
              style={{ transformOrigin: "120px 115px" }}
            />
            <circle cx="82" cy="112" r="2" fill="white" />
            <circle cx="122" cy="112" r="2" fill="white" />
          </>
        )}

        {/* Mouth */}
        {mood === "happy" && (
          <path
            d="M 80 145 Q 100 165 120 145"
            stroke="var(--foreground)"
            strokeWidth="5"
            fill="none"
            strokeLinecap="round"
          />
        )}
        {mood === "neutral" && (
          <line
            x1="85"
            y1="150"
            x2="115"
            y2="150"
            stroke="var(--foreground)"
            strokeWidth="5"
            strokeLinecap="round"
          />
        )}
        {mood === "sad" && (
          <path
            d="M 80 158 Q 100 140 120 158"
            stroke="var(--foreground)"
            strokeWidth="5"
            fill="none"
            strokeLinecap="round"
          />
        )}

        {/* Cheeks */}
        {mood === "happy" && (
          <>
            <circle cx="65" cy="140" r="6" fill="var(--danger-soft)" opacity="0.5" />
            <circle cx="135" cy="140" r="6" fill="var(--danger-soft)" opacity="0.5" />
          </>
        )}

        {/* Arms */}
        <ellipse
          cx="22"
          cy={mood === "sad" ? 180 : 130}
          rx="10"
          ry="16"
          fill="var(--watt-body)"
          stroke="var(--foreground)"
          strokeWidth="4"
          transform={waving ? "rotate(-30 22 130)" : undefined}
        />
        <ellipse
          cx="178"
          cy={mood === "sad" ? 180 : 130}
          rx="10"
          ry="16"
          fill="var(--watt-body)"
          stroke="var(--foreground)"
          strokeWidth="4"
        />

        {/* Feet */}
        <ellipse
          cx="70"
          cy="222"
          rx="18"
          ry="10"
          fill="var(--watt-body)"
          stroke="var(--foreground)"
          strokeWidth="4"
        />
        <ellipse
          cx="130"
          cy="222"
          rx="18"
          ry="10"
          fill="var(--watt-body)"
          stroke="var(--foreground)"
          strokeWidth="4"
        />
      </svg>
    </div>
  );
}
