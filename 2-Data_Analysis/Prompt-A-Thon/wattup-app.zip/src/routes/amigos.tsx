import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search, UserPlus, Crown } from "lucide-react";
import { MobileShell } from "@/components/MobileShell";
import { BottomNav } from "@/components/BottomNav";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useRequireSession } from "@/hooks/use-session";
import { addFriend, getFriends, getMonthStats } from "@/lib/store";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/amigos")({
  head: () => ({
    meta: [
      { title: "Amigos y ranking — WattUp" },
      { name: "description", content: "Compite con tus amigos por ahorrar más energía." },
    ],
  }),
  component: AmigosPage,
});

function moodFromBattery(p: number): "happy" | "neutral" | "sad" {
  if (p >= 70) return "happy";
  if (p >= 40) return "neutral";
  return "sad";
}

function AmigosPage() {
  const session = useRequireSession();
  const [query, setQuery] = useState("");
  const [tick, setTick] = useState(0);
  const friends = useMemo(() => getFriends(), [tick]);

  if (!session) return null;

  const myKWh = getMonthStats(session.userId).kWhAhorrados;
  const myEntry = {
    id: "me",
    nombre: session.nombre,
    username: "tú",
    color: "var(--primary)",
    semanaKWhAhorrados: Math.round(myKWh * 10) / 10,
    bateriaPct: Math.min(100, 30 + Math.round(myKWh * 5)),
    isMe: true,
  };

  const ranking = [...friends.map((f) => ({ ...f, isMe: false })), myEntry]
    .sort((a, b) => b.semanaKWhAhorrados - a.semanaKWhAhorrados)
    .slice(0, 10);

  const filtered = friends.filter(
    (f) =>
      !query ||
      f.username.toLowerCase().includes(query.toLowerCase()) ||
      f.nombre.toLowerCase().includes(query.toLowerCase()),
  );

  function handleAdd() {
    const u = query.trim();
    if (!u) return;
    if (friends.some((f) => f.username === u.toLowerCase())) {
      toast.info("Ya tienes a ese amigo");
      return;
    }
    addFriend(u);
    toast.success(`@${u} añadido`);
    setQuery("");
    setTick((t) => t + 1);
  }

  return (
    <MobileShell withNav>
      <header className="px-6 pt-8 pb-3">
        <h1 className="text-2xl font-black">Amigos</h1>
        <p className="text-sm text-muted-foreground">Compite y ahorra en familia</p>
      </header>

      {/* Buscador */}
      <div className="px-6 flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar usuario"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-9 h-11 rounded-2xl"
          />
        </div>
        <Button onClick={handleAdd} className="h-11 rounded-2xl px-4">
          <UserPlus className="h-4 w-4" />
        </Button>
      </div>

      {/* Mis amigos */}
      <div className="px-6 mt-5">
        <h2 className="text-base font-bold mb-2">Mis amigos</h2>
        <div className="space-y-2">
          {filtered.map((f) => (
            <Card key={f.id} className="p-3 rounded-2xl flex items-center gap-3">
              <Avatar nombre={f.nombre} color={f.color} />
              <div className="flex-1 min-w-0">
                <p className="font-bold text-sm truncate">{f.nombre}</p>
                <p className="text-xs text-muted-foreground truncate">@{f.username}</p>
              </div>
              <BatteryPill pct={f.bateriaPct} />
            </Card>
          ))}
          {filtered.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-4">
              Sin resultados. Pulsa + para añadir.
            </p>
          )}
        </div>
      </div>

      {/* Ranking semanal */}
      <div className="px-6 mt-6">
        <h2 className="text-base font-bold mb-2 flex items-center gap-2">
          <Crown className="h-4 w-4 text-[color:var(--energy)]" />
          Ranking semanal
        </h2>
        <Card className="rounded-2xl divide-y divide-border overflow-hidden">
          {ranking.map((r, i) => (
            <div
              key={r.id}
              className={cn(
                "flex items-center gap-3 p-3",
                r.isMe && "bg-primary/10",
              )}
            >
              <span
                className={cn(
                  "w-6 text-center font-black",
                  i === 0 && "text-[color:var(--energy)]",
                  i === 1 && "text-muted-foreground",
                  i === 2 && "text-[color:var(--danger-soft)]",
                )}
              >
                {i + 1}
              </span>
              <Avatar nombre={r.nombre} color={r.color} small />
              <div className="flex-1 min-w-0">
                <p className={cn("text-sm font-bold truncate", r.isMe && "text-primary")}>
                  {r.nombre} {r.isMe && "(tú)"}
                </p>
                <p className="text-[11px] text-muted-foreground">
                  {r.semanaKWhAhorrados.toFixed(1)} kWh ahorrados
                </p>
              </div>
              <MiniWatt mood={moodFromBattery(r.bateriaPct)} />
            </div>
          ))}
        </Card>
      </div>

      <BottomNav />
    </MobileShell>
  );
}

function Avatar({ nombre, color, small }: { nombre: string; color: string; small?: boolean }) {
  const initials = nombre
    .split(" ")
    .map((s) => s[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
  return (
    <div
      className={cn(
        "rounded-full flex items-center justify-center font-black text-white shrink-0",
        small ? "h-9 w-9 text-xs" : "h-11 w-11 text-sm",
      )}
      style={{ background: color }}
    >
      {initials}
    </div>
  );
}

function BatteryPill({ pct }: { pct: number }) {
  const color =
    pct >= 70 ? "var(--primary)" : pct >= 40 ? "var(--energy)" : "var(--danger-soft)";
  return (
    <div className="flex items-center gap-2">
      <div className="w-12 h-3 rounded-full bg-muted overflow-hidden">
        <div
          className="h-full rounded-full transition-all"
          style={{ width: `${pct}%`, background: color }}
        />
      </div>
      <span className="text-xs font-bold tabular-nums" style={{ color }}>
        {pct}%
      </span>
    </div>
  );
}

function MiniWatt({ mood }: { mood: "happy" | "neutral" | "sad" }) {
  const color =
    mood === "happy"
      ? "var(--primary)"
      : mood === "neutral"
        ? "var(--energy)"
        : "var(--danger-soft)";
  return (
    <div
      className="w-7 h-9 rounded-md border-2 border-foreground/80 relative shrink-0"
      style={{ background: color }}
    >
      <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-3 h-1 rounded-sm bg-foreground/80" />
      <div className="absolute inset-x-1 top-2 flex justify-between">
        <span className="block w-1 h-1 rounded-full bg-foreground" />
        <span className="block w-1 h-1 rounded-full bg-foreground" />
      </div>
    </div>
  );
}
