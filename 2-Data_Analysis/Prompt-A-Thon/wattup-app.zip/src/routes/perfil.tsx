import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { LogOut } from "lucide-react";
import { MobileShell } from "@/components/MobileShell";
import { BottomNav } from "@/components/BottomNav";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useRequireSession } from "@/hooks/use-session";
import {
  getBadges,
  getMonthStats,
  getRacha,
  getWeekActivities,
} from "@/lib/store";
import { DAILY_GOAL_EUR, fmtEuro, nivelUsuario } from "@/lib/energy";
import { logout } from "@/lib/auth";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/perfil")({
  head: () => ({
    meta: [
      { title: "Perfil — WattUp" },
      { name: "description", content: "Tus estadísticas y logros." },
    ],
  }),
  component: PerfilPage,
});

const DAYS = ["L", "M", "X", "J", "V", "S", "D"];

function PerfilPage() {
  const session = useRequireSession();
  const navigate = useNavigate();

  const data = useMemo(() => {
    if (!session) return null;
    return {
      racha: getRacha(session.userId),
      stats: getMonthStats(session.userId),
      week: getWeekActivities(session.userId),
      badges: getBadges(session.userId),
    };
  }, [session]);

  if (!session || !data) return null;
  const nivel = nivelUsuario(data.racha);
  const initials = session.nombre
    .split(" ")
    .map((s) => s[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
  const goalKWh = DAILY_GOAL_EUR / 0.18;
  const maxKWh = Math.max(...data.week.map((d) => d.kWh), goalKWh) * 1.15;
  const totalSemana = data.week.reduce((s, d) => s + d.kWh, 0);
  const promedio = totalSemana / 7;

  return (
    <MobileShell withNav>
      <header className="px-6 pt-8 pb-4 flex items-center gap-4">
        <div
          className="h-16 w-16 rounded-full flex items-center justify-center text-xl font-black text-white shadow"
          style={{ background: "var(--primary)" }}
        >
          {initials}
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl font-black truncate">{session.nombre}</h1>
          <p className="text-sm text-muted-foreground truncate">{session.email}</p>
          <div className="mt-1 inline-flex items-center gap-1 text-xs font-bold bg-primary/10 text-primary rounded-full px-2 py-0.5">
            {nivel.emoji} {nivel.nombre} · racha {data.racha}d
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full"
          onClick={() => {
            logout();
            navigate({ to: "/" });
          }}
          aria-label="Cerrar sesión"
        >
          <LogOut className="h-5 w-5" />
        </Button>
      </header>

      {/* KPIs del mes */}
      <div className="px-6 grid grid-cols-3 gap-2">
        <Card className="p-3 rounded-2xl text-center">
          <p className="text-[10px] text-muted-foreground">kWh ahorrados</p>
          <p className="text-lg font-black text-primary">
            {data.stats.kWhAhorrados.toFixed(1)}
          </p>
        </Card>
        <Card className="p-3 rounded-2xl text-center">
          <p className="text-[10px] text-muted-foreground">€ ahorrados</p>
          <p className="text-lg font-black text-primary">
            {fmtEuro(data.stats.eurosAhorrados)}
          </p>
        </Card>
        <Card className="p-3 rounded-2xl text-center">
          <p className="text-[10px] text-muted-foreground">CO₂ evitado</p>
          <p className="text-lg font-black text-primary">
            {data.stats.co2EvitadoKg.toFixed(1)}kg
          </p>
        </Card>
      </div>

      {/* Gráfico semanal */}
      <div className="px-6 mt-5">
        <div className="flex items-end justify-between mb-2">
          <h2 className="text-base font-bold">Esta semana</h2>
          <p className="text-[11px] text-muted-foreground">
            Media{" "}
            <span className="font-bold text-foreground">{promedio.toFixed(1)} kWh</span>
          </p>
        </div>
        <WeekChart week={data.week} maxKWh={maxKWh} goalKWh={goalKWh} />
      </div>

      {/* Insignias */}
      <div className="px-6 mt-5">
        <h2 className="text-base font-bold mb-2">Insignias</h2>
        <div className="grid grid-cols-4 gap-2">
          {data.badges.map((b) => (
            <Card
              key={b.id}
              className={cn(
                "aspect-square rounded-2xl flex flex-col items-center justify-center p-1 text-center transition-all",
                b.desbloqueada
                  ? "bg-[color:var(--energy)]/30 border-[color:var(--energy)] border-2"
                  : "opacity-40 grayscale",
              )}
              title={b.descripcion}
            >
              <span className="text-2xl">{b.emoji}</span>
              <span className="text-[9px] font-bold leading-tight mt-0.5">{b.nombre}</span>
            </Card>
          ))}
        </div>
      </div>

      <BottomNav />
    </MobileShell>
  );
}

function WeekChart({
  week,
  maxKWh,
  goalKWh,
}: {
  week: { date: string; kWh: number; euros: number }[];
  maxKWh: number;
  goalKWh: number;
}) {
  const [selected, setSelected] = useState<number | null>(week.length - 1);
  const todayIdx = week.length - 1;
  const goalPct = (goalKWh / maxKWh) * 100;
  const sel = selected !== null ? week[selected] : null;
  const selDate = sel ? new Date(sel.date) : null;
  const fmtDate = (d: Date) =>
    d.toLocaleDateString("es-ES", { weekday: "long", day: "numeric", month: "short" });

  return (
    <Card className="p-4 rounded-2xl">
      {/* Cabecera con detalle del día seleccionado */}
      <div className="flex items-end justify-between mb-3 min-h-[42px]">
        {sel && selDate ? (
          <>
            <div>
              <p className="text-[11px] text-muted-foreground capitalize">
                {fmtDate(selDate)}
              </p>
              <p className="text-lg font-black leading-tight">
                {sel.kWh.toFixed(2)}{" "}
                <span className="text-xs text-muted-foreground font-bold">kWh</span>
              </p>
            </div>
            <div
              className={cn(
                "text-sm font-black px-2 py-1 rounded-lg",
                sel.euros > DAILY_GOAL_EUR
                  ? "bg-[color:var(--danger-soft)]/20 text-[color:var(--danger-soft)]"
                  : "bg-primary/10 text-primary",
              )}
            >
              {fmtEuro(sel.euros)}
            </div>
          </>
        ) : (
          <p className="text-xs text-muted-foreground">Toca una barra para ver el detalle</p>
        )}
      </div>

      {/* Gráfico */}
      <div className="relative h-36">
        {/* Línea de objetivo */}
        <div
          className="absolute left-0 right-0 border-t-2 border-dashed border-[color:var(--energy)]/70 z-10 pointer-events-none"
          style={{ bottom: `${goalPct}%` }}
        >
          <span className="absolute -top-4 right-0 text-[9px] font-black bg-[color:var(--energy)] text-[color:var(--energy-foreground)] px-1.5 py-0.5 rounded">
            Objetivo {fmtEuro(DAILY_GOAL_EUR)}
          </span>
        </div>

        <div className="flex items-end justify-between gap-1.5 h-full">
          {week.map((d, i) => {
            const h = maxKWh > 0 ? Math.max(3, (d.kWh / maxKWh) * 100) : 3;
            const over = d.euros > DAILY_GOAL_EUR;
            const isSelected = selected === i;
            const isToday = i === todayIdx;
            return (
              <button
                key={d.date}
                type="button"
                onClick={() => setSelected(i)}
                className="flex flex-col items-center gap-1 flex-1 h-full justify-end group"
              >
                <div className="w-full flex items-end h-full">
                  <div
                    className={cn(
                      "w-full rounded-t-lg transition-all duration-500",
                      over
                        ? "bg-[color:var(--danger-soft)]"
                        : "bg-gradient-to-t from-primary to-primary/70",
                      isSelected
                        ? "ring-2 ring-offset-2 ring-foreground/40 scale-105"
                        : "group-hover:opacity-80",
                    )}
                    style={{ height: `${h}%` }}
                  />
                </div>
                <span
                  className={cn(
                    "text-[10px] font-black transition-colors",
                    isToday
                      ? "text-primary"
                      : isSelected
                        ? "text-foreground"
                        : "text-muted-foreground",
                  )}
                >
                  {DAYS[i]}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </Card>
  );
}
