import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Watt } from "@/components/Watt";
import { MobileShell } from "@/components/MobileShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import {
  checkPassword,
  getLockoutRemaining,
  getSession,
  loginUser,
  registerUser,
} from "@/lib/auth";
import { seedDemoIfNeeded } from "@/lib/store";
import { toast } from "sonner";
import { Check, X, Eye, EyeOff, Lock } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "WattUp — Inicia sesión" },
      { name: "description", content: "Entra en WattUp y comienza a ahorrar energía con Watt." },
    ],
  }),
  component: WelcomePage,
});

function WelcomePage() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<"login" | "register">("login");

  useEffect(() => {
    if (getSession()) navigate({ to: "/dashboard" });
  }, [navigate]);

  return (
    <MobileShell>
      <div className="px-6 pt-10 pb-8 text-center">
        <h1 className="text-4xl font-black tracking-tight">
          Watt<span className="text-primary">Up</span>
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Ahorra energía jugando con Watt
        </p>
        <div className="flex justify-center mt-4">
          <Watt mood="happy" size={170} waving />
        </div>
      </div>

      <div className="px-6 pb-10">
        <Tabs value={tab} onValueChange={(v) => setTab(v as "login" | "register")}>
          <TabsList className="grid grid-cols-2 w-full h-11 rounded-2xl">
            <TabsTrigger value="login" className="rounded-xl">
              Iniciar sesión
            </TabsTrigger>
            <TabsTrigger value="register" className="rounded-xl">
              Crear cuenta
            </TabsTrigger>
          </TabsList>
          <TabsContent value="login" className="mt-5">
            <LoginForm onSuccess={() => navigate({ to: "/dashboard" })} />
          </TabsContent>
          <TabsContent value="register" className="mt-5">
            <RegisterForm
              onSuccess={() => {
                toast.success("¡Cuenta creada! Ahora inicia sesión.");
                setTab("login");
              }}
            />
          </TabsContent>
        </Tabs>

        <p className="text-[11px] text-muted-foreground text-center mt-6">
          🔒 Demo local: tus datos se guardan en este dispositivo.
        </p>
      </div>
    </MobileShell>
  );
}

function LoginForm({ onSuccess }: { onSuccess: () => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [lockMs, setLockMs] = useState(0);

  useEffect(() => {
    if (!email) return;
    const t = setInterval(() => {
      setLockMs(getLockoutRemaining(email));
    }, 1000);
    setLockMs(getLockoutRemaining(email));
    return () => clearInterval(t);
  }, [email]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    const r = await loginUser({ email, password });
    setLoading(false);
    if (r.ok) {
      seedDemoIfNeeded(r.session.userId);
      toast.success(`¡Hola, ${r.session.nombre}!`);
      onSuccess();
    } else {
      toast.error(r.error);
      setLockMs(getLockoutRemaining(email));
    }
  }

  const locked = lockMs > 0;
  const mins = Math.floor(lockMs / 60000);
  const secs = Math.floor((lockMs % 60000) / 1000);

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-1.5">
        <Label htmlFor="login-email">Email</Label>
        <Input
          id="login-email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="h-12 rounded-xl"
          placeholder="tucorreo@ejemplo.com"
        />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="login-pw">Contraseña</Label>
        <div className="relative">
          <Input
            id="login-pw"
            type={show ? "text" : "password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="h-12 rounded-xl pr-10"
          />
          <button
            type="button"
            onClick={() => setShow((s) => !s)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            aria-label="Mostrar/ocultar contraseña"
          >
            {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {locked && (
        <Card className="p-3 flex items-center gap-3 border-[color:var(--danger-soft)] bg-[color:var(--danger-soft)]/10">
          <Lock className="h-5 w-5 text-[color:var(--danger-soft)]" />
          <div className="text-sm">
            <p className="font-bold">Cuenta bloqueada</p>
            <p className="text-muted-foreground">
              Demasiados intentos. Espera {mins}:{secs.toString().padStart(2, "0")}
            </p>
          </div>
        </Card>
      )}

      <Button
        type="submit"
        disabled={loading || locked}
        className="w-full h-12 rounded-2xl text-base font-bold"
      >
        {loading ? "Entrando..." : "Entrar"}
      </Button>
    </form>
  );
}

function RegisterForm({ onSuccess }: { onSuccess: () => void }) {
  const [nombre, setNombre] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);
  const check = checkPassword(password);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (password !== confirm) {
      toast.error("Las contraseñas no coinciden");
      return;
    }
    setLoading(true);
    const r = await registerUser({ nombre, email, password });
    setLoading(false);
    if (r.ok) onSuccess();
    else toast.error(r.error);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-1.5">
        <Label htmlFor="reg-name">Nombre</Label>
        <Input
          id="reg-name"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
          required
          className="h-12 rounded-xl"
          placeholder="Tu nombre"
        />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="reg-email">Email</Label>
        <Input
          id="reg-email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="h-12 rounded-xl"
          placeholder="tucorreo@ejemplo.com"
        />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="reg-pw">Contraseña</Label>
        <Input
          id="reg-pw"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          className="h-12 rounded-xl"
        />
        {password && (
          <div className="space-y-2 pt-1">
            <div className="flex gap-1">
              {[0, 1, 2, 3].map((i) => (
                <div
                  key={i}
                  className={cn(
                    "h-1.5 flex-1 rounded-full transition-colors",
                    i < check.score
                      ? check.score >= 4
                        ? "bg-primary"
                        : check.score >= 3
                          ? "bg-[color:var(--energy)]"
                          : "bg-[color:var(--danger-soft)]"
                      : "bg-muted",
                  )}
                />
              ))}
            </div>
            <ul className="space-y-1">
              {check.rules.map((r) => (
                <li
                  key={r.label}
                  className={cn(
                    "flex items-center gap-2 text-xs",
                    r.ok ? "text-primary" : "text-muted-foreground",
                  )}
                >
                  {r.ok ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
                  {r.label}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="reg-confirm">Confirmar contraseña</Label>
        <Input
          id="reg-confirm"
          type="password"
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          required
          className="h-12 rounded-xl"
        />
      </div>
      <Button
        type="submit"
        disabled={loading || !check.ok || password !== confirm}
        className="w-full h-12 rounded-2xl text-base font-bold"
      >
        {loading ? "Creando..." : "Crear cuenta"}
      </Button>
    </form>
  );
}
