import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowLeft, Minus, Plus } from "lucide-react";
import { Watt } from "@/components/Watt";
import { MobileShell } from "@/components/MobileShell";
import { BottomNav } from "@/components/BottomNav";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useRequireSession } from "@/hooks/use-session";
import {
  ActivityEntry,
  APPLIANCES,
  ApplianceId,
  calcularConsumo,
  estadoWatt,
  fmtEuro,
  fmtKWh,
} from "@/lib/energy";
import { saveActivity } from "@/lib/store";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/registrar")({
  head: () => ({
    meta: [
      { title: "Registrar día — WattUp" },
      { name: "description", content: "Registra el uso de tus electrodomésticos." },
    ],
  }),
  component: RegistrarPage,
});

function RegistrarPage() {
  const session = useRequireSession();
  const navigate = useNavigate();
  const [horasPorAp, setHoras] = useState<Record<ApplianceId, number>>(
    {} as Record<ApplianceId, number>,
  );

  const entries: ActivityEntry[] = useMemo(
    () =>
      (Object.entries(horasPorAp) as [ApplianceId, number][])
        .filter(([, h]) => h > 0)
        .map(([applianceId, horas]) => ({ applianceId, horas })),
    [horasPorAp],
  );

  const calc = useMemo(() => calcularConsumo(entries), [entries]);
  const watt = estadoWatt(calc.euros);

  function changeHoras(id: ApplianceId, delta: number) {
    setHoras((prev) => {
      const next = Math.max(0, Math.round(((prev[id] ?? 0) + delta) * 4) / 4);
      return { ...prev, [id]: next };
    });
  }

  function handleSave() {
    if (!session) return;
    if (entries.length === 0) {
      toast.error("Añade al menos un electrodoméstico");
      return;
    }
    saveActivity(session.userId, entries);
    toast.success("¡Día guardado! Watt te lo agradece.");
    setTimeout(() => navigate({ to: "/dashboard" }), 400);
  }

  if (!session) return null;

  return (
    <MobileShell withNav>
      <header className="px-6 pt-6 pb-3 flex items-center gap-3">
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full"
          onClick={() => navigate({ to: "/dashboard" })}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-black">Registrar mi día</h1>
      </header>

      <div className="flex justify-center">
        <Watt mood={watt.mood} size={120} />
      </div>

      {/* Lista electrodomésticos */}
      <div className="px-6 mt-4 space-y-2">
        {APPLIANCES.map((ap) => {
          const horas = horasPorAp[ap.id] ?? 0;
          const active = horas > 0;
          return (
            <Card
              key={ap.id}
              className={cn(
                "p-3 rounded-2xl flex items-center gap-3 transition-all",
                active && "border-primary border-2 bg-primary/5",
              )}
            >
              <div className="text-3xl">{ap.emoji}</div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-sm truncate">{ap.nombre}</p>
                <p className="text-[11px] text-muted-foreground truncate">{ap.tip}</p>
                <p className="text-[10px] font-bold text-primary mt-0.5">
                  ⏱ Recomendado: {ap.horasRecomendadas < 1
                    ? `${Math.round(ap.horasRecomendadas * 60)} min`
                    : `${ap.horasRecomendadas}h`}/día
                </p>
              </div>
              <div className="flex items-center gap-1">
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  className="h-8 w-8 rounded-full"
                  onClick={() => changeHoras(ap.id, -0.25)}
                  disabled={horas <= 0}
                >
                  <Minus className="h-3.5 w-3.5" />
                </Button>
                <div className="w-14 text-center text-sm font-bold tabular-nums">
                  {horas > 0 ? `${horas}h` : "—"}
                </div>
                <Button
                  type="button"
                  size="icon"
                  className="h-8 w-8 rounded-full"
                  onClick={() => changeHoras(ap.id, 0.25)}
                >
                  <Plus className="h-3.5 w-3.5" />
                </Button>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Resumen comparativo */}
      <div className="px-6 mt-5 grid grid-cols-2 gap-3">
        <Card className="p-3 rounded-2xl border-2 border-[color:var(--danger-soft)] bg-[color:var(--danger-soft)]/10">
          <p className="text-[11px] text-muted-foreground">Lo que has gastado</p>
          <p className="text-xl font-black text-[color:var(--danger-soft)]">
            {fmtEuro(calc.euros)}
          </p>
          <p className="text-[10px] text-muted-foreground">{fmtKWh(calc.kWh)}</p>
        </Card>
        <Card className="p-3 rounded-2xl border-2 border-primary bg-primary/10">
          <p className="text-[11px] text-muted-foreground">Uso responsable</p>
          <p className="text-xl font-black text-primary">{fmtEuro(calc.eurosResponsable)}</p>
          <p className="text-[10px] text-muted-foreground">{fmtKWh(calc.kWhResponsable)}</p>
        </Card>
      </div>

      <div className="px-6 mt-3">
        <Card className="p-4 rounded-2xl bg-primary/15 border-0 text-center">
          <p className="text-xs text-muted-foreground">Podrías ahorrar hoy</p>
          <p className="text-3xl font-black text-primary">{fmtEuro(calc.ahorroEuros)}</p>
          <p className="text-xs text-primary font-bold">
            🌍 {calc.co2EvitadoKg.toFixed(2)} kg CO₂ evitados
          </p>
        </Card>
      </div>

      <div className="px-6 mt-5">
        <Button
          onClick={handleSave}
          className="w-full h-14 rounded-2xl text-base font-black shadow-lg"
        >
          Guardar mi día
        </Button>
      </div>

      <BottomNav />
    </MobileShell>
  );
}
