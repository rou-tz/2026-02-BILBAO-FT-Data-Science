import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { Watt } from "@/components/Watt";
import { MobileShell } from "@/components/MobileShell";
import { BottomNav } from "@/components/BottomNav";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useRequireSession } from "@/hooks/use-session";
import { getTodayActivity } from "@/lib/store";
import { APPLIANCE_MAP, DAILY_GOAL_EUR, estadoWatt, fmtEuro, fmtKWh } from "@/lib/energy";
import { Zap, Plus } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Inicio — WattUp" },
      { name: "description", content: "Tu resumen energético del día." },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  const session = useRequireSession();
  const today = useMemo(() => (session ? getTodayActivity(session.userId) : null), [session]);

  if (!session) return null;

  const eurosHoy = today?.euros ?? 0;
  const { mood, porcentaje } = estadoWatt(eurosHoy);
  const top3 = (today?.entries ?? [])
    .map((e) => {
      const ap = APPLIANCE_MAP[e.applianceId];
      const k = ap.kWhPorHora * e.horas;
      return { ap, kWh: k, euros: k * 0.18 };
    })
    .sort((a, b) => b.kWh - a.kWh)
    .slice(0, 3);

  const overGoal = eurosHoy > DAILY_GOAL_EUR;

  return (
    <MobileShell withNav>
      <header className="px-6 pt-8 pb-2">
        <p className="text-sm text-muted-foreground">¡Hola, {session.nombre}!</p>
        <h1 className="text-2xl font-black">Tu día con Watt</h1>
      </header>

      {/* Watt + progreso circular */}
      <div className="relative flex flex-col items-center mt-4">
        <div className="relative">
          <CircularProgress value={porcentaje} size={260} over={overGoal} />
          <div className="absolute inset-0 flex items-center justify-center">
            <Watt mood={mood} size={180} />
          </div>
        </div>
        <p
          className={cn(
            "mt-2 text-sm font-semibold",
            overGoal ? "text-[color:var(--danger-soft)]" : "text-muted-foreground",
          )}
        >
          {overGoal
            ? `¡Has superado tu objetivo! ${porcentaje}%`
            : `Has usado el ${porcentaje}% de tu objetivo`}
        </p>
      </div>

      {/* Tarjeta de gasto */}
      <div className="px-6 mt-4">
        <Card
          className={cn(
            "p-4 rounded-2xl border-2 animate-pop-in",
            overGoal
              ? "border-[color:var(--danger-soft)] bg-[color:var(--danger-soft)]/10"
              : "border-primary bg-primary/5",
          )}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground">Hoy has gastado</p>
              <p
                className={cn(
                  "text-2xl font-black",
                  overGoal ? "text-[color:var(--danger-soft)]" : "text-primary",
                )}
              >
                {fmtEuro(eurosHoy)}
              </p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Objetivo</p>
              <p className="text-base font-bold">{fmtEuro(DAILY_GOAL_EUR)}</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Top 3 electrodomésticos */}
      <div className="px-6 mt-5">
        <h2 className="text-base font-bold mb-2">Top de hoy</h2>
        {top3.length === 0 ? (
          <Card className="p-4 rounded-2xl text-center text-sm text-muted-foreground">
            Aún no has registrado actividad hoy 👇
          </Card>
        ) : (
          <div className="space-y-2">
            {top3.map(({ ap, kWh, euros }) => (
              <Card
                key={ap.id}
                className="p-3 rounded-2xl flex items-center gap-3 animate-slide-up"
              >
                <div className="text-3xl">{ap.emoji}</div>
                <div className="flex-1">
                  <p className="font-bold text-sm">{ap.nombre}</p>
                  <p className="text-xs text-muted-foreground">{fmtKWh(kWh)}</p>
                </div>
                <p className="font-black text-primary">{fmtEuro(euros)}</p>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* CTA */}
      <div className="px-6 mt-5">
        <Button
          asChild
          className="w-full h-14 rounded-2xl text-base font-black bg-[color:var(--energy)] text-[color:var(--energy-foreground)] hover:bg-[color:var(--energy)]/90 shadow-lg"
        >
          <Link to="/registrar">
            <Plus className="h-5 w-5" />
            Registrar mi día
          </Link>
        </Button>
      </div>

      <BottomNav />
    </MobileShell>
  );
}

function CircularProgress({
  value,
  size,
  over = false,
}: {
  value: number;
  size: number;
  over?: boolean;
}) {
  const stroke = 14;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (value / 100) * c;
  return (
    <svg width={size} height={size} className="-rotate-90">
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        stroke="var(--muted)"
        strokeWidth={stroke}
        fill="none"
      />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        stroke={over ? "var(--danger-soft)" : "var(--primary)"}
        strokeWidth={stroke}
        fill="none"
        strokeLinecap="round"
        strokeDasharray={c}
        strokeDashoffset={offset}
        style={{ transition: "stroke-dashoffset 0.8s ease, stroke 0.4s ease" }}
      />
    </svg>
  );
}
